const Category = require('./models/Category');

const secaoPaes = new Category(
  1,
  'Pães',
  'Pães frescos e quentinhos',
  '🍞'
);

secaoPaes.addProduct();
console.log('Quantos produtos temos?', secaoPaes.productCount);